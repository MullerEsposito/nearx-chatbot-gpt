export type Interaction = {
  prompt: string;
  response: string;
};